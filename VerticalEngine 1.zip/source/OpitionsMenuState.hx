package;

import flixel.FlxG;
import flixel.FlxState;
import flixel.FlxSprite;
import flixel.text.FlxText;
import flixel.util.FlxColor;
import flixel.util.FlxSave;

class OptionsMenuState extends FlxState
{
	// Lista de preferências que o jogador pode alterar
	private var opcoes:Array<String> = ["Scroll: UPSCROLL", "Splashes: LIGADO", "Delay de Audio: 0ms", "VOLTAR"];
	private var textosOpcoes:Array<FlxText> = [];
	private var idSelecionado:Int = 0;

	// Variáveis de controle de preferências (padrão do motor)
	public static var downscroll:Bool = false;
	public static var noteSplashes:Bool = true;
	public static var audioDelay:Int = 0;

	private var salvar:FlxSave; // Sistema nativo para salvar as configurações no celular

	override public function create():Void
	{
		super.create();

		// Fundo escuro estético para destacar as opções
		var fundo:FlxSprite = new FlxSprite().makeGraphic(FlxG.width, FlxG.height, FlxColor.fromRGB(20, 15, 25));
		add(fundo);

		// Título do Menu
		var titulo:FlxText = new FlxText(0, 50, FlxG.width, "PREFERENCIAS", 32);
		titulo.setFormat(null, 32, FlxColor.YELLOW, CENTER, OUTLINE, FlxColor.BLACK);
		add(titulo);

		// Carrega as opções salvas anteriormente no celular (se existirem)
		salvar = new FlxSave();
		salvar.bind("VerticalEnginePrefs");
		carregarPreferencias();

		// Atualiza o texto visual com as opções salvas
		atualizarTextosInterface();

		// Cria os textos na tela vertical
		for (i in 0...opcoes.length)
		{
			var texto:FlxText = new FlxText(0, 220 + (i * 90), FlxG.width, opcoes[i], 24);
			texto.setFormat(null, 24, FlxColor.WHITE, CENTER, OUTLINE, FlxColor.BLACK);
			add(texto);
			textosOpcoes.push(texto);
		}

		mudarSelecao(0);
	}

	override public function update(elapsed:Float):Void
	{
		super.update(elapsed);

		// Controles por toque na tela vertical do celular
		if (FlxG.mouse.justPressed)
		{
			if (FlxG.mouse.y < FlxG.height / 3) {
				mudarSelecao(-1); // Toque na parte superior sobe
			} else if (FlxG.mouse.y > (FlxG.height / 3) * 2) {
				mudarSelecao(1);  // Toque na parte inferior desce
			} else {
				confirmarOpcao(); // Toque no centro altera a opção ou volta
			}
		}
	}

	private function mudarSelecao(mudar:Int):Void
	{
		idSelecionado += mudar;
		if (idSelecionado < 0) idSelecionado = opcoes.length - 1;
		if (idSelecionado >= opcoes.length) idSelecionado = 0;

		// Efeito visual de destaque na opção selecionada
		for (i in 0...textosOpcoes.length)
		{
			if (i == idSelecionado) {
				textosOpcoes[i].color = FlxColor.CYAN;
				textosOpcoes[i].scale.set(1.1, 1.1);
			} else {
				textosOpcoes[i].color = FlxColor.WHITE;
				textosOpcoes[i].scale.set(1.0, 1.0);
			}
		}
	}

	private function confirmarOpcao():Void
	{
		switch (idSelecionado)
		{
			case 0:
				downscroll = !downscroll;
			case 1:
				noteSplashes = !noteSplashes;
			case 2:
				audioDelay += 10;
				if (audioDelay > 150) audioDelay = 0; // Reseta se passar de 150ms
			case 3:
				salvarPreferencias();
				FlxG.switchState(new MainMenuState()); // Volta para o Menu Principal de forma segura
				return;
		}

		atualizarTextosInterface();
		salvarPreferencias();
	}

	private function atualizarTextosInterface():Void
	{
		opcoes[0] = "Scroll: " + (downscroll ? "DOWNSCROLL" : "UPSCROLL");
		opcoes[1] = "Splashes: " + (noteSplashes ? "LIGADO" : "DESLIGADO");
		opcoes[2] = "Delay de Audio: " + audioDelay + "ms";

		for (i in 0...textosOpcoes.length) {
			if (textosOpcoes[i] != null) textosOpcoes[i].text = opcoes[i];
		}
	}

	private function salvarPreferencias():Void
	{
		salvar.data.downscroll = downscroll;
		salvar.data.noteSplashes = noteSplashes;
		salvar.data.audioDelay = audioDelay;
		salvar.flush(); // Grava os dados fisicamente no armazenamento do celular
	}

	private function carregarPreferencias():Void
	{
		if (salvar.data.downscroll != null) downscroll = salvar.data.downscroll;
		if (salvar.data.noteSplashes != null) noteSplashes = salvar.data.noteSplashes;
		if (salvar.data.audioDelay != null) audioDelay = salvar.data.audioDelay;
	}
}
