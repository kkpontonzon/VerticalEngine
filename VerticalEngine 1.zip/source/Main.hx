package;

import flixel.FlxGame;
import openfl.display.Sprite;

class Main extends Sprite
{
	public function new()
	{
		super();
		// Inicializa o jogo na nossa proporção vertical (450x800)
		// Começando pela tela do Menu Principal (que vamos criar a seguir)
		addChild(new FlxGame(450, 800, MainMenuState, 60, 60, true));
	}
}
