package;

import flixel.FlxG;
import flixel.FlxState;
import flixel.FlxSprite;
import flixel.text.FlxText;
import flixel.util.FlxColor;
import flixel.math.FlxMath;

class MainMenuState extends FlxState
{
	// Variáveis para os botões e efeitos visuais
	private var opcoesMenu:Array<String> = ["STORY MODE", "FREEPLAY", "CHART EDITOR", "OPTIONS"];
	private var textosMenu:Array<FlxText> = [];
	private var idSelecionado:Int = 0;
	
	// Fundo estético
	private var fundoGradiente:FlxSprite;
	private var destinoY:Float = 0;

	override public function create():Void
	{
		super.create();

		// Habilita o mouse/touch para podermos interagir na tela vertical
		FlxG.mouse.visible = true;

		// 1. CRIANDO O FUNDO ESTÉTICO (Lindeza Visual)
		// Um sprite simples que mudará de cor suavemente depois
		fundoGradiente = new FlxSprite().makeGraphic(FlxG.width, FlxG.height, FlxColor.fromRGB(30, 20, 40));
		fundoGradiente.scrollFactor.set(0, 0.1); // Efeito Parallax suave
		add(fundoGradiente);

		// 2. CRIANDO OS BOTÕES VERTICAIS
		for (i in 0...opcoesMenu.length)
		{
			var texto:FlxText = new FlxText(0, 250 + (i * 100), FlxG.width, opcoesMenu[i]);
			texto.setFormat(null, 32, FlxColor.WHITE, CENTER);
			texto.borderStyle = OUTLINE;
			texto.borderSize = 3;
			texto.borderColor = FlxColor.BLACK;
			
			add(texto);
			textosMenu.push(texto);
		}

		atualizarSelecao();
	}

	override public function update(elapsed:Float):Void
	{
		super.update(elapsed);

		// Controles simples por teclado ou toque na metade superior/inferior da tela
		if (FlxG.keys.justPressed.UP || (FlxG.mouse.justPressed && FlxG.mouse.y < FlxG.height / 2)) {
			mudarSelecao(-1);
		}
		if (FlxG.keys.justPressed.DOWN || (FlxG.mouse.justPressed && FlxG.mouse.y >= FlxG.height / 2)) {
			mudarSelecao(1);
		}

		// Transição para a próxima tela ao apertar ENTER ou Clique Duplo (futuramente)
		if (FlxG.keys.justPressed.ENTER) {
			selecionarOpcao();
		}

		// 3. SUAVEZA (Lerp) - Faz os botões se moverem de forma fluida
		for (i in 0...textosMenu.length) {
			// Efeito visual: o item selecionado fica levemente maior e brilha
			if (i == idSelecionado) {
				textosMenu[i].scale.x = FlxMath.lerp(textosMenu[i].scale.x, 1.2, 0.1);
				textosMenu[i].scale.y = FlxMath.lerp(textosMenu[i].scale.y, 1.2, 0.1);
				textosMenu[i].color = FlxColor.CYAN; // Cor neon de destaque
			} else {
				textosMenu[i].scale.x = FlxMath.lerp(textosMenu[i].scale.x, 1.0, 0.1);
				textosMenu[i].scale.y = FlxMath.lerp(textosMenu[i].scale.y, 1.0, 0.1);
				textosMenu[i].color = FlxColor.WHITE;
			}
		}
	}

	private function mudarSelecao(mudar:Int):Void
	{
		idSelecionado += mudar;
		if (idSelecionado < 0) idSelecionado = opcoesMenu.length - 1;
		if (idSelecionado >= opcoesMenu.length) idSelecionado = 0;
		
		atualizarSelecao();
	}

	private function atualizarSelecao():Void
	{
		// Aqui podemos tocar o som de "tick" de menu do FNF original depois!
	}

	private function selecionarOpcao():Void
{
	switch(opcoesMenu[idSelecionado]) {
		case "OPTIONS":
			FlxG.switchState(new OptionsMenuState()); // Agora abre o menu de preferências!
		case "CHART EDITOR":
			// Próximo passo da nossa lista!
		case "STORY MODE":
			// Modos de jogo futuros...
	}
}
